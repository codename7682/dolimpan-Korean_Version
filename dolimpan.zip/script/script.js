$(document).ready(function(){
    
    var num;
    var name = [];
    
    $("#create").click(function(){
        num = $("#num").val();
        num = parseInt(num);
        if(isNaN(num) || num<=0){
            alert("정확히 숫자를 입력해 주세요.");
        }else{
            for(i=0 ; i<num ; i++){
                $("#list").append((i+1)+" <input type='text' class='username' /><br/>");
            }
            $("#rotate").show();
        }
    });
    
    $("#rotate").click(function(){
        var val = 1;
        for(i=0 ; i<num ; i++){
            name[i] = $(".username").eq(i).val();
            val *= name[i].length;
        }
        if(val != 0){
            rot(num);
        }else{
            alert("이름을 입력해 주세요");
        }
    });
    
    function rot(){
        var deg = 360 / num;
        var raddeg = deg/2 * Math.PI / 180;
        var x = Math.tan(raddeg) * 250 * 2;
        for(i=0; i<num; i++){
            $("#stage").append("<div class='s s"+i+"'><span>"+name[i]+"</span></div>");
            $(".s"+i).css({
                width: x+"px",
                borderLeft: x/2+"px solid transparent",
                borderRight: x/2+"px solid transparent",
                transform: "translateX(-50%) rotate("+(deg*i)+"deg)",
                borderTopColor: "rgb("+rand(100,255)+","+rand(100,255)+","+rand(100,255)+")"
            });
        }
        
        $("#stage").animate({
            dummy: rand(900,3000)
        },{
            duration: rand(3000,9000),
            easing: "easeOutQuart",
            step: function(now,fx){
                $(this).css({
                    transform: "rotate("+now+"deg)"
                })
            }
        });
    }
    
    function rand(min,max){
        return Math.floor(Math.random()*(max + 1 - min) + min);
    }
});










